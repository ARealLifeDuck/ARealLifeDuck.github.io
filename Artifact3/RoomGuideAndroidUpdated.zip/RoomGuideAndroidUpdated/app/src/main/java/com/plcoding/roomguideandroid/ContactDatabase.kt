package com.plcoding.roomguideandroid

import androidx.room.Database
import androidx.room.RoomDatabase

// No changes needed for this to work.
@Database(
    entities = [Contact::class],
    version = 1
)
abstract class ContactDatabase: RoomDatabase() {

    abstract val dao: ContactDao
}