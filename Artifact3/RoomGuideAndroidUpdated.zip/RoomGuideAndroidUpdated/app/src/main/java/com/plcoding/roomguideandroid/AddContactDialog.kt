package com.plcoding.roomguideandroid

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.AlertDialog
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AddContactDialog(
    state: ContactState,
    onEvent: (ContactEvent) -> Unit,
    modifier: Modifier = Modifier
) {
    AlertDialog(
        modifier = modifier,
        onDismissRequest = {
            onEvent(ContactEvent.HideDialog)
        },
        title = { Text(text = "Add contact") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextField(
                    value = state.petName,
                    onValueChange = {
                        onEvent(ContactEvent.SetPetName(it))
                    },
                    placeholder = {
                        Text(text = "Animal's Name")
                    }
                )
                TextField(
                    value = state.animalType,
                    onValueChange = {
                        onEvent(ContactEvent.SetAnimalType(it))
                    },
                    placeholder = {
                        Text(text = "Animal's Type")
                    }
                )
                TextField(
                    value = state.gender,
                    onValueChange = {
                        onEvent(ContactEvent.SetGender(it))
                    },
                    placeholder = {
                        Text(text = "Animal's Gender")
                    }
                )
                TextField(
                    value = state.age,
                    onValueChange = {
                        onEvent(ContactEvent.SetAge(it))
                    },
                    placeholder = {
                        Text(text = "Animal's Age")
                    }
                )
                TextField(
                    value = state.weight,
                    onValueChange = {
                        onEvent(ContactEvent.SetWeight(it))
                    },
                    placeholder = {
                        Text(text = "Animal's Weight")
                    }
                )
                TextField(
                    value = state.acqDate,
                    onValueChange = {
                        onEvent(ContactEvent.SetAcqDate(it))
                    },
                    placeholder = {
                        Text(text = "Acquisition Date: 04/02/2019")
                    }
                )
                TextField(
                    value = state.acqCountry,
                    onValueChange = {
                        onEvent(ContactEvent.SetAcqCountry(it))
                    },
                    placeholder = {
                        Text(text = "Acquisition Country")
                    }
                )
                TextField(
                    value = state.reserved,
                    onValueChange = {
                        onEvent(ContactEvent.SetReserved(it))
                    },
                    placeholder = {
                        Text(text = "Reserved: Yes or No")
                    }
                )
                TextField(
                    value = state.serviceCountry,
                    onValueChange = {
                        onEvent(ContactEvent.SetServiceCountry(it))
                    },
                    placeholder = {
                        Text(text = "Country of Service")
                    }
                )
            }
        },
        buttons = {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.CenterEnd
            ) {
                Button(onClick = {
                    onEvent(ContactEvent.SaveContact)
                }) {
                    Text(text = "Save")
                }
            }
        }
    )
}