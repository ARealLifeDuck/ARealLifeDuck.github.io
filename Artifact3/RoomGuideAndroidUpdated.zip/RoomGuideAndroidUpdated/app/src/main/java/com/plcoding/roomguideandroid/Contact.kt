package com.plcoding.roomguideandroid

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
//Updated from the original code by Philip to contain the 9 fields for the animal information
data class Contact(
    val petName: String,
    val animalType: String,
    val gender: String,
    val age: String,
    val weight: String,
    val acqDate: String,
    val acqCountry: String,
    val reserved: String,
    val serviceCountry: String,
    // This will auto create the primary key which must be unique for each entry.
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0
)
