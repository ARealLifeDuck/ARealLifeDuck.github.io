package com.plcoding.roomguideandroid

enum class SortType {
    ID,
    PET_NAME,
    AGE,
    ACQ_DATE,
    SERVICE_COUNTRY
}