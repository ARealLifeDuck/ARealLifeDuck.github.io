package com.plcoding.roomguideandroid

sealed interface ContactEvent {
    object SaveContact: ContactEvent
    // TODO Change these to reflect new classes for updating the fields.
    data class SetPetName(val petName: String): ContactEvent
    data class SetAnimalType(val animalType: String): ContactEvent
    data class SetGender(val gender: String): ContactEvent
    data class SetAge(val age: String): ContactEvent
    data class SetWeight(val weight: String): ContactEvent
    data class SetAcqDate(val acqDate: String): ContactEvent
    data class SetAcqCountry(val acqCountry: String): ContactEvent
    data class SetReserved(val reserved: String): ContactEvent
    data class SetServiceCountry(val serviceCountry: String): ContactEvent
    object ShowDialog: ContactEvent
    object HideDialog: ContactEvent
    data class SortContacts(val sortType: SortType): ContactEvent
    data class DeleteContact(val contact: Contact): ContactEvent
}