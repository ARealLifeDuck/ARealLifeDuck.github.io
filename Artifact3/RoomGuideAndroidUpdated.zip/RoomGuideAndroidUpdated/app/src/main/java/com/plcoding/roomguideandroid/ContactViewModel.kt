package com.plcoding.roomguideandroid

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ContactViewModel(
    private val dao: ContactDao
): ViewModel() {

    private val _sortType = MutableStateFlow(SortType.PET_NAME)
    private val _contacts = _sortType
        .flatMapLatest { sortType ->
            when(sortType) {
                SortType.ID -> dao.contactsById()
                SortType.PET_NAME -> dao.contactsByName()
                SortType.AGE -> dao.contactsByAge()
                SortType.ACQ_DATE -> dao.contactsByAcqDate()
                SortType.SERVICE_COUNTRY -> dao.contactsByServiceCountry()
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList())

    private val _state = MutableStateFlow(ContactState())
    val state = combine(_state, _sortType, _contacts) { state, sortType, contacts ->
        state.copy(
            contacts = contacts,
            sortType = sortType
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ContactState())

    fun onEvent(event: ContactEvent) {
        when(event) {

            is ContactEvent.DeleteContact -> {
                viewModelScope.launch {
                    dao.deleteContact(event.contact)
                }
            }
            ContactEvent.HideDialog -> {
                _state.update { it.copy(
                    isAddingContact = false
                ) }
            }
            ContactEvent.SaveContact -> {
                val petName = state.value.petName
                val animalType = state.value.animalType
                val gender = state.value.gender
                val age = state.value.age
                val weight = state.value.weight
                val acqDate = state.value.acqDate
                val acqCountry = state.value.acqCountry
                val reserved = state.value.reserved
                val serviceCountry = state.value.serviceCountry

                if(petName.isBlank() || animalType.isBlank() || gender.isBlank() || age.isBlank() || weight.isBlank() || acqDate.isBlank() || acqCountry.isBlank() || reserved.isBlank() || serviceCountry.isBlank()) {
                    return
                }

                val contact = Contact(
                    petName = petName,
                    animalType = animalType,
                    gender = gender,
                    age = age,
                    weight = weight,
                    acqDate = acqDate,
                    acqCountry = acqCountry,
                    reserved = reserved,
                    serviceCountry = serviceCountry
                )
                viewModelScope.launch {
                    dao.upsertContact(contact)
                }
                _state.update { it.copy(
                    isAddingContact = false,
                    petName = "",
                    animalType = "",
                    gender = "",
                    age = "",
                    weight = "",
                    acqDate = "",
                    acqCountry = "",
                    reserved = "",
                    serviceCountry = ""
                ) }
            }
            is ContactEvent.SetAcqCountry -> {
                _state.update { it.copy(
                    acqCountry = event.acqCountry
                ) }
            }
            is ContactEvent.SetAcqDate -> {
                _state.update { it.copy(
                    acqDate = event.acqDate
                ) }
            }
            is ContactEvent.SetAge -> {
                _state.update { it.copy(
                    age = event.age
                ) }
            }
            is ContactEvent.SetAnimalType -> {
                _state.update { it.copy(
                    animalType = event.animalType
                ) }
            }
            is ContactEvent.SetGender -> {
                _state.update { it.copy(
                    gender = event.gender
                ) }
            }
            is ContactEvent.SetPetName -> {
                _state.update { it.copy(
                    petName = event.petName
                ) }
            }
            is ContactEvent.SetReserved -> {
                _state.update { it.copy(
                    reserved = event.reserved
                ) }
            }
            is ContactEvent.SetServiceCountry -> {
                _state.update { it.copy(
                    serviceCountry = event.serviceCountry
                ) }
            }
            is ContactEvent.SetWeight -> {
                _state.update { it.copy(
                    weight = event.weight
                ) }
            }
            ContactEvent.ShowDialog -> {
                _state.update { it.copy(
                    isAddingContact = true
                ) }
            }
            is ContactEvent.SortContacts -> {
                _sortType.value = event.sortType
            }
        }
    }
}