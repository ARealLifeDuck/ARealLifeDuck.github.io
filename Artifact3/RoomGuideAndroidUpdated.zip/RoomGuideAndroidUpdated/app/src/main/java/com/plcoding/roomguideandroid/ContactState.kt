package com.plcoding.roomguideandroid

data class ContactState(
    val contacts: List<Contact> = emptyList(),
    val id: Int = 0,
    val petName: String = "",
    val animalType: String = "",
    val gender: String = "",
    val age: String = "",
    val weight: String = "",
    val acqDate: String = "",
    val acqCountry: String = "",
    val reserved: String = "",
    val serviceCountry: String = "",
    val isAddingContact: Boolean = false,
    val sortType: SortType = SortType.PET_NAME
)
