package com.plcoding.roomguideandroid

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {

    @Upsert // These next two are the same as original due to needing to Update/Insert and Delete
    suspend fun upsertContact(contact: Contact)

    @Delete
    suspend fun deleteContact(contact: Contact)

    // Updated the Queries so that the name is more concise and added a few more options
    // across the application.
    @Query("SELECT * FROM contact ORDER BY id ASC")
    fun contactsById(): Flow<List<Contact>>

    @Query("SELECT * FROM contact ORDER BY petName ASC")
    fun contactsByName(): Flow<List<Contact>>

    @Query("SELECT * FROM contact ORDER BY age ASC")
    fun contactsByAge(): Flow<List<Contact>>

    @Query("SELECT * FROM contact ORDER BY acqDate ASC")
    fun contactsByAcqDate(): Flow<List<Contact>>

    @Query("SELECT * FROM contact ORDER BY serviceCountry ASC")
    fun contactsByServiceCountry(): Flow<List<Contact>>
}